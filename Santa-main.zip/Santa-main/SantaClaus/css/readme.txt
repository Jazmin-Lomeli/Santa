

This font was created by Michel LUN, http://www.peax-webdesign.com 

--------------------------------------------------------------------------

You can use it for free on your personal projects

--------------------------------------------------------------------------

For commercial projects, please contact me at : contact@peax-webdesign.com

--------------------------------------------------------------------------

Follow me on Facebook https://fr-fr.facebook.com/peax.webdesign

and

G+                https://plus.google.com/103595703505477716588

to know about future fonts

--------------------------------------------------------------------------